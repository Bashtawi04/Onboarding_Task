"""Offline regression checks: no Azure calls or credentials needed."""

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import ask
from onboarding.records import Records


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.context = Records(ask.ROOT / "data").context(
            "NH-2606", "NH-2606"
        )

    def test_weekday_corrected(self):
        self.assertEqual(
            ask.correct_weekdays(
                "2026-10-25 (Monday)", self.context
            ),
            "2026-10-25 (Sunday)",
        )

    def test_correct_weekday_unchanged(self):
        text = "2026-10-25 (Sunday)"
        self.assertEqual(
            ask.correct_weekdays(text, self.context), text
        )

    def test_unrelated_weekday_unchanged(self):
        self.assertEqual(
            ask.correct_weekdays("Meet Monday.", self.context),
            "Meet Monday.",
        )

    def test_payroll_reversal_corrected(self):
        text = (
            "2026-10-25 is before the cutoff. "
            "Bring your passport."
        )
        fixed = ask.payroll_fallback(text, self.context)
        self.assertIn("2026-11-26", fixed)
        self.assertIn("Bring your passport.", fixed)
        self.assertNotIn("is before", fixed)

    def test_correct_payroll_unchanged(self):
        text = "2026-10-25 is after the cutoff."
        self.assertEqual(
            ask.payroll_fallback(text, self.context), text
        )

    def test_it_false_conflict_corrected(self):
        fixed = ask.it_conflict_override(
            "The IT account deadline does not match policy.",
            self.context,
        )
        self.assertIn("The dates match.", fixed)

    def test_it_actual_conflict_not_overridden(self):
        self.context["it_account_policy_check"]["dates_match"] = False
        text = "The IT account deadline does not match policy."
        self.assertEqual(
            ask.it_conflict_override(text, self.context), text
        )

    def test_task_fields_stay_together(self):
        tasks = [
            {
                "task_name": "Laptop",
                "owner_team": "IT",
                "due_date": "2026-10-18",
                "status": "In progress",
            },
            {
                "task_name": "Account",
                "owner_team": "IT",
                "due_date": "2026-10-15",
                "status": "Done",
            },
        ]
        text = ask.task_table(tasks)

        self.assertIn(
            "| Laptop | IT | 2026-10-18 | In progress |", text
        )
        self.assertIn(
            "| Account | IT | 2026-10-15 | Done |", text
        )

    def test_named_colleague_requires_clarification(self):
        with self.assertRaises(PermissionError):
            ask.access_context(
                "NH-2606",
                "NH-2606",
                "What is open for Daniel Mwangi?",
                ask.DEFAULT_TODAY,
            )

    def test_denial_before_api(self):
        client = MagicMock()

        with tempfile.TemporaryDirectory() as folder:
            with patch.object(ask, "ARTIFACTS", Path(folder)):
                result = ask.run_query(
                    "NH-2606",
                    "NH-2610",
                    "Open tasks?",
                    client=client,
                )

        self.assertEqual(result["outcome"], "declined")
        client.embeddings.create.assert_not_called()
        client.responses.create.assert_not_called()

    def test_hybrid_keeps_distinct_pages(self):
        chunks = [
            {
                "chunk_id": str(index),
                "file_path": "it.md",
                "page": index // 2,
                "text": "MFA password",
                "embedding": [1.0, 0.0],
            }
            for index in range(4)
        ]

        result = ask.retrieve(
            chunks, [1.0, 0.0], "MFA", "hybrid"
        )
        self.assertEqual(len(result), 2)

    def test_invalid_rerank_falls_back(self):
        client = MagicMock()
        client.responses.create.return_value = SimpleNamespace(
            output_text="[99]"
        )
        candidates = [{"text": "example"}]

        result, status = ask.rerank(
            client, "question", candidates
        )

        self.assertEqual(result, candidates)
        self.assertEqual(status, "invalid_output_fallback")

    def test_end_to_end_task_rendering(self):
        client = MagicMock()
        client.embeddings.create.return_value = SimpleNamespace(
            data=[SimpleNamespace(embedding=[1.0, 0.0])]
        )
        client.responses.create.return_value = SimpleNamespace(
            output_text=json.dumps({
                "explanation": "See the recorded tasks. [R2]",
                "task_ids": [],
            })
        )

        index = {
            "chunks": [{
                "chunk_id": "x",
                "file_path": "policy.md",
                "page": 1,
                "text": "Example policy.",
                "embedding": [1.0, 0.0],
            }]
        }

        with tempfile.TemporaryDirectory() as folder:
            with patch.object(ask, "ARTIFACTS", Path(folder)):
                result = ask.run_query(
                    "NH-2606",
                    "NH-2606",
                    "What is still open?",
                    client=client,
                    index=index,
                )

        self.assertEqual(result["outcome"], "answer_generated")

        for task in self.context["open_tasks"]:
            self.assertIn(task["task_name"], result["answer"])

        self.assertIn(
            "| Task | Owner | Due date | Status |",
            result["answer"],
        )


if __name__ == "__main__":
    unittest.main()
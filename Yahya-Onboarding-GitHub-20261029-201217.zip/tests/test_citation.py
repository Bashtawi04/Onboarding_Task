"""Test citation extraction from the actual ask.py implementation."""

import ast
import unittest
from pathlib import Path


class CitationTests(unittest.TestCase):
    def extract(self, explanation):
        path = Path(__file__).resolve().parents[1] / "ask.py"
        tree = ast.parse(path.read_text(encoding="utf-8-sig"))

        function = next(
            node for node in tree.body
            if isinstance(node, ast.FunctionDef)
            and node.name == "run_query"
        )

        assignments = {}

        for node in ast.walk(function):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        if target.id in ("brackets", "labels"):
                            assignments[target.id] = node

        self.assertEqual(set(assignments), {"brackets", "labels"})

        code = ast.Module(
            body=[
                assignments["brackets"],
                assignments["labels"],
            ],
            type_ignores=[],
        )

        import re

        namespace = {"explanation": explanation, "re": re}
        exec(compile(code, str(path), "exec"), namespace)
        return namespace["labels"]

    def test_adjacent_citations(self):
        self.assertEqual(self.extract("[S1][S2]"), {"S1", "S2"})

    def test_separated_citations(self):
        self.assertEqual(
            self.extract("Policy [S1]. Employee [R1]."),
            {"S1", "R1"},
        )

    def test_grouped_citations(self):
        self.assertEqual(self.extract("[S1, R2]"), {"S1", "R2"})

    def test_unknown_label_is_preserved_for_validation(self):
        self.assertEqual(self.extract("[S99]"), {"S99"})

    def test_missing_citations_remain_missing(self):
        self.assertEqual(self.extract("No citations here."), set())


if __name__ == "__main__":
    unittest.main()
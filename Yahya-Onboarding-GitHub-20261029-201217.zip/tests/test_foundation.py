import unittest
from pathlib import Path
from datetime import date
from onboarding.records import Records, working_days_before
from onboarding.documents import manifest, chunks

DATA = Path(__file__).resolve().parents[1] / 'data'


class FoundationTests(unittest.TestCase):
    def setUp(self):
        self.records = Records(DATA)

    def test_colleague_cannot_access_other_hire(self):
        with self.assertRaises(PermissionError):
            self.records.context('NH-2607', 'NH-2610')

    def test_manager_can_access_direct_report(self):
        self.assertEqual(self.records.context('E1084', 'NH-2610')['record']['new_hire_id'], 'NH-2610')

    def test_unrelated_manager_cannot_access(self):
        with self.assertRaises(PermissionError):
            self.records.context('E1001', 'NH-2610')

    def test_unknown_identity_denied(self):
        with self.assertRaises(PermissionError):
            self.records.context('unknown', 'NH-2602')

    def test_first_pay_after_cutoff(self):
        self.assertEqual(self.records.first_pay('2026-10-25')['pay_date'], '2026-11-26')
        self.assertEqual(self.records.first_pay('2026-09-27')['pay_date'], '2026-10-28')

    def test_cutoff_inclusive(self):
        self.assertEqual(self.records.first_pay('2026-10-15')['pay_date'], '2026-10-28')

    def test_missing_calendar_does_not_invent_date(self):
        self.assertEqual(self.records.first_pay('2026-12-20')['status'], 'unavailable')

    def test_working_day_subtraction(self):
        self.assertEqual(working_days_before(date(2026, 11, 10), 3), date(2026, 11, 5))

    def test_open_tasks_and_priority(self):
        result = self.records.context('NH-2602', 'NH-2602')
        self.assertEqual(len(result['open_tasks']), 2)
        self.assertTrue(result['open_tasks'][0]['overdue'])
        self.assertEqual(self.records.context('NH-2604', 'NH-2604')['open_tasks'][0]['status'], 'Blocked')

    def test_corpus_has_no_archive_hris_or_eval(self):
        paths = [r['file_path'] for r in manifest(DATA)]
        self.assertEqual(len(paths), 11)
        self.assertFalse(any('archive/' in p or 'hris/' in p or 'eval/' in p for p in paths))

    def test_bad_chunk_parameters(self):
        with self.assertRaises(ValueError):
            list(chunks(DATA, 100, 100))


if __name__ == '__main__':
    unittest.main()

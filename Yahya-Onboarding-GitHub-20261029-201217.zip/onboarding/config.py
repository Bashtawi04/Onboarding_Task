"""Shared Azure settings for the onboarding assistant."""

import os
from getpass import getpass


def read_setting(name, default):
    """Use an environment setting, or the default if it is missing."""
    value = os.getenv(name, "").strip()
    return value or default


ENDPOINT = read_setting(
    "AZURE_OPENAI_ENDPOINT",
    "https://yahya-onboarding-rag-resource.services.ai.azure.com/openai/v1/",
).rstrip("/") + "/"

CHAT_MODEL = read_setting(
    "AZURE_OPENAI_CHAT_DEPLOYMENT",
    "gpt-5.4-mini",
)

EMBEDDING_MODEL = read_setting(
    "AZURE_OPENAI_EMBEDDING_DEPLOYMENT",
    "text-embedding-3-small",
)

DEFAULT_CHUNK_SIZE = 400
DEFAULT_CHUNK_OVERLAP = 100


def get_api_key():
    """Read the key from the environment, or ask without displaying it."""
    key = os.getenv("AZURE_OPENAI_API_KEY", "").strip()

    if not key:
        key = getpass(
            "Paste your Azure API key, then press Enter: "
        ).strip()

    if not key:
        raise ValueError("No Azure API key supplied.")

    return key
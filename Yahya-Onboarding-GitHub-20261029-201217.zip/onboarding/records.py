"""Structured records stay out of the vector index."""

import csv
from datetime import date, timedelta
from pathlib import Path

# Fixed date required by the training task.
DEFAULT_TODAY = date(2026, 10, 16)

WEEKDAYS_EN = (
    "Monday", "Tuesday", "Wednesday", "Thursday",
    "Friday", "Saturday", "Sunday",
)

WEEKDAYS_AR = (
    "الاثنين", "الثلاثاء", "الأربعاء", "الخميس",
    "الجمعة", "السبت", "الأحد",
)


def date_fact(value: str) -> dict:
    """Python calculates the weekday instead of asking AI to guess."""
    parsed = date.fromisoformat(value)

    return {
        "date": value,
        "weekday_en": WEEKDAYS_EN[parsed.weekday()],
        "weekday_ar": WEEKDAYS_AR[parsed.weekday()],
    }


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def working_days_before(start: date, count: int) -> date:
    """Count backwards using Sunday–Thursday working days."""
    if count < 0:
        raise ValueError("count must be nonnegative")

    while count:
        start -= timedelta(days=1)

        # Python uses Monday=0, so Friday=4 and Saturday=5.
        if start.weekday() not in (4, 5):
            count -= 1

    return start


class Records:
    def __init__(self, data: Path):
        self.hires = {
            row["new_hire_id"]: row
            for row in read_csv(data / "hris/new_hires.csv")
        }

        self.tasks = read_csv(data / "hris/onboarding_tasks.csv")

        self.calendar = {
            row["month"]: row
            for row in read_csv(data / "hris/payroll_calendar_2026.csv")
        }

    def authorised_record(self, asker: str, target: str) -> dict:
        """Allow own record or a manager's direct report."""
        # CLI IDs simulate users. They are not real sign-in.
        record = self.hires.get(target)

        if record is None or not (
            asker == target or asker == record["manager_id"]
        ):
            raise PermissionError(
                "I cannot share that record. Please contact HR."
            )

        return dict(record)

    def first_pay(self, start: str) -> dict:
        joining = date.fromisoformat(start)
        joining_month = joining.strftime("%Y-%m")
        calendar = self.calendar.get(joining_month)

        if calendar is None:
            return {
                "status": "unavailable",
                "reason": "Joining month missing from payroll calendar",
            }

        # Preserve the joining month's cutoff before selecting pay month.
        joining_cutoff = calendar["cutoff_date"]
        after_cutoff = joining > date.fromisoformat(joining_cutoff)

        if after_cutoff:
            following_month = (
                joining.replace(day=28) + timedelta(days=4)
            ).replace(day=1)

            calendar = self.calendar.get(
                following_month.strftime("%Y-%m")
            )

        if calendar is None:
            return {
                "status": "unavailable",
                "reason": "Required pay month missing from payroll calendar",
            }

        relationship = "after" if after_cutoff else "on or before"

        return {
            "status": "scheduled_under_start_date_rule",
            "pay_date": calendar["pay_date"],
            "joining_date": start,
            "joining_month_cutoff": joining_cutoff,
            "cutoff_relationship": (
                "after" if after_cutoff else "on_or_before"
            ),
            "cutoff_explanation_en": (
                f"{start} is {relationship} "
                f"the joining-month cutoff {joining_cutoff}."
            ),
            "pay_month": calendar["month"],
            "pay_date_details": date_fact(calendar["pay_date"]),
            "after_joining_month_cutoff": after_cutoff,
            "coverage": (
                "joining part-month plus next full month"
                if after_cutoff
                else "joining part-month"
            ),
            "condition": (
                "Payment requires a verified IBAN; "
                "confirm unresolved bank details with Payroll."
            ),
            "sources": [
                "procedures/ONB-04_Payroll_Bank_Account_and_WPS.pdf",
                "hris/payroll_calendar_2026.csv",
            ],
        }

    def context(
        self,
        asker: str,
        target: str,
        today: date = DEFAULT_TODAY,
    ) -> dict:
        record = self.authorised_record(asker, target)

        tasks = [
            dict(task)
            for task in self.tasks
            if task["new_hire_id"] == target
            and task["status"] != "Done"
        ]

        for task in tasks:
            task["overdue"] = (
                date.fromisoformat(task["due_date"]) < today
            )

        # Blocked tasks first, then overdue tasks, then other open tasks.
        tasks.sort(
            key=lambda task: (
                0 if task["status"] == "Blocked"
                else 1 if task["overdue"]
                else 2,
                task["due_date"],
            )
        )

        start_date = date.fromisoformat(record["start_date"])

        it_account_due = working_days_before(
            start_date, 1
        ).isoformat()

        recorded_it_task = next(
            (
                task
                for task in self.tasks
                if task["new_hire_id"] == target
                and task["task_code"] == "IT_ACCOUNT"
            ),
            None,
        )

        it_policy_check = {
            "rule": (
                "IT creates account one Sunday-Thursday working day "
                "before start date, subject to HR confirming signed contract"
            ),
            "policy_due_date": it_account_due,
            "recorded_task_due_date": (
                recorded_it_task["due_date"]
                if recorded_it_task else None
            ),
            "task_status": (
                recorded_it_task["status"]
                if recorded_it_task else "Not specified"
            ),
            "dates_match": (
                recorded_it_task["due_date"] == it_account_due
                if recorded_it_task else None
            ),
            "policy_source": (
                "procedures/ONB-05_IT_Access_and_Equipment.md, section 1"
            ),
            "task_source": "hris/onboarding_tasks.csv",
        }

        payroll = self.first_pay(record["start_date"])

        request_due = working_days_before(
            start_date, 3
        ).isoformat()

        # Supply correct weekdays for the dates relevant to this employee.
        dates = {
            today.isoformat(),
            record["start_date"],
            it_account_due,
            request_due,
        }

        dates.update(task["due_date"] for task in tasks)

        for field in ("pay_date", "joining_month_cutoff"):
            if payroll.get(field):
                dates.add(payroll[field])

        date_facts = {
            value: date_fact(value)
            for value in sorted(dates)
        }

        return {
            "date_facts": date_facts,
            "today": today.isoformat(),
            "record": record,
            "open_tasks": tasks,
            "it_account_policy_check": it_policy_check,
            "scheduled_first_pay": payroll,
            "manager_it_request_due": request_due,
            "date_rule_source": (
                "procedures/ONB-05_IT_Access_and_Equipment.md, section 2"
            ),
            "record_sources": [
                "hris/new_hires.csv",
                "hris/onboarding_tasks.csv",
            ],
        }
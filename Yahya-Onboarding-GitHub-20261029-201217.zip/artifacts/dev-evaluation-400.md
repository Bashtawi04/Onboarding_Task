# Al Dana Onboarding RAG: 15-case development evaluation

Scenario date: 2026-10-16
Executed cases: 15

## Automated diagnostics
At least one listed document retrieved (answer cases only): 12/13
This is not full retrieval recall or answer correctness. Employee CSVs are outside the vector index.
Question meaning, citation-to-claim support, privacy, exclusions and gold points require manual review.
A prohibited term used in a correct negation can trigger a review flag (not an automatic failure).

| Case | Outcome | Any gold document retrieved | Review flags | Answer quality |
|---|---|---|---|---|
| DEV-01 | answer_generated | Yes | - | Pending human review |
| DEV-02 | answer_generated | Yes | - | Pending human review |
| DEV-03 | answer_generated | Yes | - | Pending human review |
| DEV-04 | answer_generated | Yes | - | Pending human review |
| DEV-05 | answer_generated | Yes | - | Pending human review |
| DEV-06 | answer_generated | Yes | - | Pending human review |
| DEV-07 | answer_generated | Yes | - | Pending human review |
| DEV-08 | answer_generated | No | - | Pending human review |
| DEV-09 | answer_generated | Yes | - | Pending human review |
| DEV-10 | answer_generated | Yes | - | Pending human review |
| DEV-11 | answer_generated | Yes | - | Pending human review |
| DEV-12 | answer_generated | Yes | - | Pending human review |
| DEV-13 | answer_generated | N/A | - | Pending human review |
| DEV-14 | declined | N/A | - | Pending human review |
| DEV-15 | answer_generated | Yes | - | Pending human review |

## Case answers and gold-check list

### DEV-01
**Question:** What's the IT helpdesk number and email, in case my laptop or login doesn't work on day one?
**Answer:** For day-one IT help, the current IT Helpdesk contact is **it.helpdesk@aldana-group.example** and extension **2300**. The helpdesk hours are **Sunday to Thursday, 06:30 to 17:00**. [S1]

For your record, the account/email creation is already **in progress** and the policy is that IT creates the account and email **one working day before your start date**, after HR confirms the signed contract. [R2][S1]
**Expected points:**
- IT Helpdesk extension 2300
- IT Helpdesk email it.helpdesk@aldana-group.example

### DEV-02
**Question:** How many hours do we work during Ramadan, and what are the hours at head office?
**Answer:** According to the current handbook, Ramadan working hours are **6 hours a day** [S1]. For **Doha HQ**, the Ramadan schedule is **09:00 to 15:00** [S1]. The FAQ says the same, but it is a lower-priority summary and the handbook controls [S2].

For your location, **Doha HQ**, the applicable Ramadan hours are **09:00–15:00** [S1].
**Expected points:**
- 6 hours a day during Ramadan (36 per week under the national limit)
- Doha HQ Ramadan hours 09:00 to 15:00

### DEV-03
**Question:** Who books my medical fitness test, and do I have to use my leave to attend?
**Answer:** The **PRO** books your medical fitness appointment at a company-approved clinic. It is planned for your first week, within five working days of your start date, and the task is owned by **PRO** [S2][R2].

You **do not need to take leave** to attend. The test time is treated as **paid working time** [S2].

Your recorded onboarding task for this is **Medical fitness test**:
- **Owner:** PRO
- **Due date:** 2026-11-02
- **Status:** Not started
- **Source:** hris/onboarding_tasks.csv [R2]

If you want, I can also tell you what documents you need to bring to the test.
**Expected points:**
- PRO books the appointment at a company-approved clinic, aiming for the first week
- It is paid working time, no leave needed
- HR and the manager only learn fit / not fit / further tests, not medical details

### DEV-04
**Question:** When is the probation review and what are the possible outcomes?
**Answer:** The probation review takes place in **month five** of probation, and probation lasts **six months from your start date**. For this employee, the start date is **2026-11-10**, so the review is expected in month five of the probation period; the procedure does **not** give a specific calendar date. [S2][R1]

The possible outcomes are **confirmed** or **not confirmed**. The manager rates each objective and gives a recommendation, and HR plus the head of department make the decision. [S2]

If you want, I can also help map the six-month probation timeline from the start date.
**Expected points:**
- Probation lasts six months
- Final probation review in month five
- Outcomes: confirmed or not confirmed, decided by HR and the head of department
- Check-ins at day 30, 60 and 90

### DEV-05
**Question:** I'm NH-2604 and I start on Sunday. What do I need to do first?
**Answer:** Since you start at Mesaieed Site, the highest-priority rule is: report to the Site Administration Office at 06:30 on your first day, ask for the site administrator, bring your original passport, and complete the full HSE induction on day one before going beyond the site office. Your ID card is issued by HR after your photo is taken, and at the site it becomes your access pass only after HSE sign-off. [S2] [S4]

For NH-2604, the matching task that is already blocked is **Pre-arrival visa paperwork**: owner **PRO**, due **2026-10-11**, status **Blocked**, source **hris/onboarding_tasks.csv**; the notes say it is blocked because the passport scan is unreadable and HR requested a new scan on 2026-10-13. [R2]

What you need to do first:
1. **Follow the site day-one reporting rule**: Mesaieed Site, 06:30, Site Administration Office, ask for the site administrator, bring your original passport. [S2]
2. **Complete the HSE induction on your first working day**; site staff start at 07:00 after reporting, and you may not go beyond the site office until it is signed off. [S4]
3. **Resolve the blocked visa paperwork** by providing the requested readable passport scan to HR/PRO; if you cannot get it in time, tell HR early. [R2] [S1]

Other relevant status:
- **IT account/laptop**: the policy deadline and the recorded task deadline match, and the task is **Done**. Account creation still depends on HR confirming the signed contract. [R3] [R2]
- **First salary** is only a scheduled estimate, not confirmation of payment. For this start date, it is scheduled for **2026-11-26 (Thursday)**, covering the **joining part-month plus next full month**, and it requires a **verified IBAN**; if bank details are unresolved, confirm them with Payroll. [R3]

If you want, I can also list all open tasks for NH-2604 in due-date order.
**Expected points:**
- Record: Overseas hire, HSE Officer, G4, Mesaieed Site, start 2026-10-18 (Sunday)
- Visa paperwork (VISA_PROCESSING) is Blocked: HR needs a readable passport scan from the new hire; owner PRO; contact HR/PRO today
- Report at 06:30 to the Site Administration Office, Mesaieed
- Full HSE induction on the first working day; no access beyond the site office until signed off
- Laptop (G4, site): collected from the Mesaieed site IT desk (ext 3300) after the induction, not from HQ; status In progress
- Medical fitness test within the first week, booked by PRO (due 2026-10-25)
- Output is a prioritised list with owner, due date and status for each step

### DEV-06
**Question:** I'm Qatari. Which of the usual new-hire steps, like visa or the medical test, do I not have to do?
**Answer:** As a **Qatari national**, you do **not** have to do the usual **visa / QID / residence steps**: the procedure says **“Nothing to do. Your QID stays as it is. The visa, medical fitness and residence steps do not apply to you.”** [S3] It also says **Qatari nationals do not have the medical fitness test step** and should **skip to section 3**. [S1]

So, for the usual new-hire steps:
- **Pre-arrival visa paperwork:** does **not** apply to you. [S4]
- **Medical fitness test:** does **not** apply to you. [S1] [S4]
- **QID / residence permit steps:** do **not** apply to you. [S4]

I’m only using the current procedure and handbook guidance here; both agree that these steps are not required for Qatari nationals. [S1] [S4]

If you want, I can also list the **new-hire steps that still do apply** to you, such as first-day reporting, ID card, IT, and HSE induction.
**Expected points:**
- Qatari national: no pre-arrival visa paperwork, no medical fitness test, no QID or residence permit application
- Still applies: documents (QID copy and IBAN), contract, ID card, bank details to Payroll, short online HSE induction within five working days, probation objectives
- Her task list contains none of VISA_PROCESSING, MEDICAL_FITNESS, QID_APPLICATION

### DEV-07
**Question:** I'm NH-2606, a maintenance technician at Mesaieed. Will I get a laptop, and where and when do I do my HSE induction?
**Answer:** Yes — **you will not get a laptop** as a Mesaieed site employee in **grade G2**. For Mesaieed/Ras Laffan site roles, **grades G1 to G3 do not get a laptop** and instead use a **shared site terminal** [S1][S2][S3].  

Your **HSE induction** is a **full site induction** because you work at **Mesaieed Site**. It is done **on your first working day**, **starts at 07:00**, and you should report first at **06:30** to the **Site Administration Office, Mesaieed Industrial City** [S2][S4]. After that, the induction takes place in the **site HSE training room** [S2][S4].  

For your record, the HSE induction task is **not started**, owned by **HSE**, due **2026-10-25**, and it is **not overdue** [R2].
**Expected points:**
- Grade G2 on site: no laptop; shared site terminal and PeopleHub kiosk, supervisor shows the login
- Full HSE induction on the first working day 2026-10-25 (Sunday), at the Mesaieed site HSE training room, starting 07:00 after reporting at 06:30
- No access beyond the site office until the induction is signed off

### DEV-08
**Question:** What is still open for me?
**Answer:** Here is what is still open for you on **2026-10-16 (Friday)** [R1][R3]:

1. **HSE induction completed** — Owner: **HSE**; Due date: **2026-10-18 (Sunday)**; Status: **In progress**; Source: **task T-2603-07** [R2][R3]  
2. **Agree probation objectives** — Owner: **Manager**; Due date: **2026-10-18 (Sunday)**; Status: **In progress**; Source: **task T-2603-08** [R2][R3]

**Blocked / overdue tasks:**  
- **Blocked:** Not specified [R2]  
- **Overdue:** Not specified [R2]

**IT account:** already done. The policy requires account creation one working day before the start date, subject to HR confirming the signed contract, and the recorded task matches that due date; status is **Done** [S3][R2].

**First salary:** scheduled for **2026-10-28 (Wednesday)** for the **joining part-month**, because your joining date **2026-10-11** is on or before the joining-month cutoff **2026-10-15**. This is only a scheduled estimate and still depends on a **verified IBAN**; please confirm any unresolved bank details with Payroll [R1][R3].

If you want, I can also group the open items by **owner** or by **due date**.
**Expected points:**
- HSE_INDUCTION: In progress, owner HSE, due 2026-10-18
- PROBATION_PLAN: In progress, owner Manager, due 2026-10-18
- All other tasks are Done
- Suggests next steps only; does not mark anything as done

### DEV-09
**Question:** Can you show me what's still open for my new joiner NH-2610 before she starts?
**Answer:** Yes — here is what is still open for NH-2610 (Dalia Mansour) before her start date of 2026-11-10 [R1].

### Open tasks
| Task | Owner | Due date | Status | Source |
|---|---|---:|---|---|
| Sign employment contract | HR | 2026-10-29 (Thursday) | Not started | [R2], [R3] |
| Submit onboarding documents to HR | New hire | 2026-11-03 (Tuesday) | Not started | [R2], [R3] |
| IT account and email created | IT | 2026-11-09 (Monday) | Not started | [R2], [R3] |
| Laptop issued | IT | 2026-11-10 (Tuesday) | Not started | [R2], [R3] |
| Company ID card issued | HR | 2026-11-12 (Thursday) | Not started | [R2], [R3] |
| Bank account details verified by Payroll | Payroll | 2026-11-15 (Sunday) | Not started | [R2], [R3] |
| HSE induction completed | HSE | 2026-11-17 (Tuesday) | Not started | [R2], [R3] |
| Medical fitness test | PRO | 2026-11-17 (Tuesday) | Not started | [R2], [R3] |
| Agree probation objectives | Manager | 2026-11-17 (Tuesday) | Not started | [R2], [R3] |
| QID / residence permit update to Al Dana | PRO | 2026-11-24 (Tuesday) | Not started | [R2], [R3] |

### Blocked / dependency notes
- IT account creation is governed by the IT procedure: IT creates the account one working day before the start date, but only after HR confirms the contract is signed. The recorded task due date matches the policy due date, and the task is still not started. [S2], [R2]
- First salary is only a scheduled estimate, not confirmation of payment. It is for the joining part-month, payable on 2026-11-26 (Thursday), and it requires a verified IBAN; unresolved bank details must be confirmed with Payroll. [R1], [R3]

### Overdue tasks
- None shown as overdue in the record. [R2]

If you want, I can also turn this into a simple “what she must do vs what HR/IT/PRO must do” checklist.
**Expected points:**
- E1084 is the manager of NH-2610, so the request is allowed
- All 10 tasks are Not started (start date 2026-11-10 (Tuesday))
- Earliest due: CONTRACT_SIGNED 2026-10-29 (HR); DOCS_SUBMITTED 2026-11-03 (New hire)
- Manager action: raise the IT equipment request at least 3 working days before start, i.e. by 2026-11-05 (Thursday)

### DEV-10
**Question:** When will I get my first salary?
**Answer:** Your first salary is scheduled for **Thursday, 26 November 2026** [R3]. This is the first pay date for your joining date of **25 October 2026**, which is **after** the joining-month cutoff of **15 October 2026** [R1]. The scheduled coverage is your **joining part-month plus the next full month** [R1].

Please note: this is a **scheduled estimate, not a confirmation of payment**. Payroll still requires a **verified IBAN** before payment can be made, so please confirm any unresolved bank details with Payroll [R1].
**Expected points:**
- Start date 2026-10-25 is after the 2026-10 cut-off 2026-10-15
- First salary is paid on the next month's pay date 2026-11-26 (Thursday)
- That payment includes the part-month of joining plus the full next month
- 28 November 2026 is a Saturday, so the pay date moves back to the Thursday

### DEV-11
**Question:** I started on 27 September. When does my first salary come?
**Answer:** According to the current payroll procedure, if your start date is after the joining-month cutoff, your first salary is paid on the next month’s pay date and includes your part-month of joining plus the full next month [S1].

Your recorded start date is 27 September 2026, and the joining-month cutoff is 15 September 2026, so 27 September is after the cutoff [R1]. That means your first salary is scheduled for 28 October 2026, which is Wednesday [R1]. This is a scheduled estimate only, and payment requires a verified IBAN [R1][S1].

So, your first salary is expected on 28 October 2026 (Wednesday), subject to a verified IBAN and Payroll processing [R1][S1].
**Expected points:**
- Start date 2026-09-27 is after the 2026-09 cut-off 2026-09-15
- First salary is paid on the next month's pay date 2026-10-28 (Wednesday)
- That payment includes the part-month of joining plus the full next month

### DEV-12
**Question:** How long do I have to complete my HSE induction? I'll be working at Ras Laffan.
**Answer:** **Applicable rule:** for **site-based staff at Ras Laffan Site**, the HSE induction is the **full induction on your first working day**, starting at **07:00 after you report at 06:30**, and **you may not go beyond the site office until it is signed off**. The procedure is the controlling source; the FAQ’s “30 days from your start date” is **outdated/overridden** for site staff and does **not apply** here. [S2] [S1] [S4]

For your record, the task **“HSE induction completed”** is assigned to **HSE**, due **2026-11-08**, status **Not started**, and it is **not overdue**. [R2]

So, for **Ras Laffan**, you do **not** have a 30-day window for this induction. You are expected to complete it **on day one** before going beyond the site office. [S2] [S1]
**Expected points:**
- Site-based: the full induction is on the first working day 2026-11-08 (Sunday), starting 07:00
- No access beyond the site office until it is signed off (ONB-06 v2.0, effective 2026-05-01)
- The FAQ answer (30 days) is outdated (FAQ last reviewed March 2025); the procedure wins over the FAQ

### DEV-13
**Question:** Can my wife and children join me in Qatar, and how long does the family residence permit take?
**Answer:** No clear family-residence rule is provided for whether your wife and children can join you in Qatar, so I can’t confirm eligibility from the available employee records and documents. Please check with HR or PRO for the family sponsorship/residence process. [S2] [S1]

For the residence permit timeline, the only matching task shows your QID / residence permit application is still **In progress** and **overdue**; PRO submitted it on **2026-10-08** and is waiting for the card to be issued. [R2] There is no approved turnaround time stated for a family residence permit in the supplied evidence, so the duration is **Not specified**. [S2] [R2]

If you meant your own QID/residence permit: the company’s PRO prepares and submits the paperwork for overseas hires, but the evidence does not give a confirmed completion date. [S2]
**Expected points:**
- The onboarding documents do not cover family residence
- Refer to HR and the PRO desk
- Does not invent a process or a processing time

### DEV-14
**Question:** Can you tell me when NH-2610 starts and which of her tasks are still open? We'll be working together.
**Answer:** I cannot share that record. Please contact HR.
**Expected points:**
- Politely declines: an employee may only see their own record; managers see their direct reports
- Offers a safe alternative, e.g. ask HR or her manager

### DEV-15
**Question:** في أي ساعة وأين أحضر في أول يوم عمل لي؟ وماذا يجب أن أحضر معي؟
**Answer:** بحسب الإجراء الحالي المعتمد، إذا كنت تعمل في **Doha HQ** فيجب أن تحضر إلى **Reception, ground floor, West Bay head office** عند **08:00 صباحًا** في أول يوم عمل لك. [S2]

وبالنسبة لما يجب أن تحضره معك، فالمطلوب هو:
- **جواز السفر الأصلي** إذا كنت من الموظفين القادمين من الخارج، أو **بطاقة الهوية القطرية (QID)** إذا كنت من المقيمين أو المواطنين القطريين. [S2]
- **تفاصيل IBAN** إذا لم تكن قد أرسلتها مسبقًا إلى Payroll. [S2]

كما يذكر خطاب الترحيب نفس تعليمات اليوم الأول لمقر الدوحة ويؤكد إحضار **جواز السفر أو QID** حسب الفئة. [S1]

ملاحظة مهمة: بالنسبة لأول راتب، فهو **تقدير مجدول فقط** وليس تأكيدًا للدفع، ويشترط **التحقق من IBAN** مع Payroll. [R1]
**Expected points:**
- الحضور إلى مكتب الاستقبال في المقر الرئيسي (غرب الخليج، الدوحة) الساعة 08:00 صباحًا
- أول يوم عمل: الأحد 1 نوفمبر 2026 (2026-11-01)
- إحضار بطاقة الهوية القطرية (QID) وبيانات الآيبان (IBAN) إن لم تُرسل إلى قسم الرواتب

# Answer review

Retrieval counts are NOT answer accuracy.
Score every expected point in scores.csv.
Check citations, unsupported claims, privacy and contradictions separately.

## NEW-01
Do I need MFA if I use the shared site terminal, and who shows me how to sign in?

Yes — for Mesaieed Site staff in grades G1 to G3, the shared site terminal is used and the procedure says they do not get a laptop.
MFA is still mandatory for everybody, and at the first sign-in you set up MFA yourself after IT gives you temporary sign-in details in person on day one.
For G1 to G3 site staff, the supervisor shows you how to log in to the shared site terminal; the handbook repeats that site staff use shared site terminals, but that lower-priority advice is overridden by the current IT procedure, which specifically assigns the login help to the supervisor.
[S1] [S3] [S2]

Expected points:
- [ ] MFA is mandatory for everybody.
- [ ] G2 site staff use a shared terminal and PeopleHub kiosk.
- [ ] The supervisor shows the employee how to log in.

Other issues / unsupported claims / citation errors: __________________

## NEW-02
Should I travel to HQ for my laptop, and can I collect it before HSE sign-off?

No, as a Ras Laffan Site grade G4 overseas hire you should not travel to HQ to collect the laptop; site staff never need to travel to HQ for equipment.
The controlling IT procedure says G4 and above at Ras Laffan collect the laptop at the IT desk on their own site, and only after HSE induction is signed off.
[S1] Your day-one instructions for Ras Laffan are to report to the Site Administration Office at 06:30, bring your original passport, and wear closed shoes and long trousers; PPE is issued at induction.
[S3] The HSE induction for site staff starts on day one at 07:00, and you may not go beyond the site office until it is signed off, so you cannot collect the laptop before HSE sign-off.
[S3] The FAQ’s shorter note that site staff of grade G4 and above get a laptop is overridden by the numbered procedures on the collection location and HSE prerequisite.
[S2][S5]

Expected points:
- [ ] Collect at the Ras Laffan site IT desk, not HQ.
- [ ] HSE induction must be signed off before collection.
- [ ] G4 site laptop includes VPN access.

Other issues / unsupported claims / citation errors: __________________

## NEW-03
IT asked me for my password. Should I share it, and who can help with an MFA problem?

Do not share your password: Al Dana’s IT procedure says you must not share it with anybody, including IT, and IT will never ask for it; if someone asks, that conflicts with the rule and is overridden by the procedure.
[S2] For a password or MFA problem, use the self-service password portal for a forgotten password; if you are locked out, have a new phone, or MFA is not working, contact the IT Helpdesk on extension 2300, or the site IT desk if you are at a site.
[S2] MFA is mandatory for everybody, and your first sign-in is where you set your own password and configure MFA.
[S2]

Expected points:
- [ ] Do not share the password, including with IT.
- [ ] Contact IT Helpdesk extension 2300 for MFA problems.

Other issues / unsupported claims / citation errors: __________________

## NEW-04
Does my buddy decide whether I pass probation? Explain who recommends, who decides, and when reviews happen.

No—your buddy does not decide probation.
The buddy is only a colleague who helps with small questions; they are not your boss and have no say in the probation result.
[S3] The manager recommends the outcome by rating each probation objective in the final review, and HR plus the head of department make the decision.
[S3]
For timing, probation lasts six months from your start date.
[S3] In the first week, within five working days of your start date, your manager agrees three to five probation objectives with you and records them in PeopleHub.
[S3] Your manager then meets you at day 30, day 60, and day 90 for check-ins, and the HR Business Partner checks that all three happened.
[S3] The final probation review takes place in month five, before the six-month probation ends.
[S3]
What is missing here is the exact calendar dates for the 30/60/90-day check-ins and the month-five review, so I cannot calculate them beyond the relative milestones supplied.

[S3]

Expected points:
- [ ] Buddy has no say in the probation result.
- [ ] Manager rates objectives and recommends.
- [ ] HR and head of department decide confirmed or not confirmed.
- [ ] Final review is month five within six-month probation.
- [ ] Check-ins occur on days 30, 60 and 90.

Other issues / unsupported claims / citation errors: __________________

## NEW-05
For NH-2610, when must I request equipment and when is the IT account due? Keep the deadlines separate.

For NH-2610, the separate deadlines are: the line manager must request equipment by 2026-11-05, and IT account creation is due on 2026-11-09.
The account deadline is one working day before the 2026-11-10 start date and is only after HR confirms the contract is signed.
[S1][R1][R2][R3]

IT account policy deadline: 2026-11-09; recorded deadline: 2026-11-09; recorded status: Not started. The dates match. The separate manager equipment-request deadline is 2026-11-05. Account creation requires HR confirmation of the signed contract. [R1][R2][R3]

Expected points:
- [ ] Manager equipment request due 2026-11-05.
- [ ] IT account policy deadline 2026-11-09.
- [ ] Account creation depends on HR confirming the signed contract.

Other issues / unsupported claims / citation errors: __________________

## NEW-06
When is my first salary scheduled, and is that guaranteed if my bank details are not verified?

Your first salary is scheduled for **2026-11-26 (Thursday)** because your start date, **2026-11-15**, is on or before the November payroll cut-off of **2026-11-15**; this means it falls in the November run and covers the joining part-month.
[R1][R3][S1]
It is **not guaranteed** if your bank details are not verified: payment requires a **verified IBAN**, and unresolved bank details must be confirmed with Payroll.
[R3][S1]
Because the evidence does not show that your bank details are already verified, what is missing is verification of the IBAN by Payroll.
Please refer to HR/Payroll for that status.
[R3][S1]

Scheduled first pay: **2026-11-26**. 2026-11-15 is on or before the joining-month cutoff 2026-11-15. Coverage: joining part-month. Payment requires a verified IBAN; confirm unresolved bank details with Payroll. [R1][R3]

Expected points:
- [ ] Start date 2026-11-15 is on the joining-month cutoff.
- [ ] First salary scheduled 2026-11-26.
- [ ] Payment requires a verified IBAN; the schedule is not a payment guarantee.

Other issues / unsupported claims / citation errors: __________________

## NEW-07
What remains open for me and who owns it? Include the recorded deadline and status.

Open item: QID / residence permit application.
Owner: PRO.
Recorded deadline: 2026-10-11.
Status: In progress; the notes say the application was submitted on 2026-10-08 and PRO is chasing while waiting for the card to be issued.
[R2]

Recorded tasks [R2]
| Task | Owner | Due date | Status |
|---|---|---|---|
| QID / residence permit application | PRO | 2026-10-11 | In progress |
Overdue against the scenario date: QID / residence permit application. [R2][R3]

Expected points:
- [ ] QID / residence permit application is the only open task.
- [ ] Owner PRO; due 2026-10-11; status In progress.
- [ ] It is overdue against the scenario date 2026-10-16.

Other issues / unsupported claims / citation errors: __________________

## NEW-08
What tasks are still open for Daniel Mwangi?

Please specify the employee ID with --target. Access will be checked before any record is shared.

Expected points:
- [ ] Request an explicit target employee ID or decline.
- [ ] Do not reveal Daniel records or substitute Ramesh task details.

Other issues / unsupported claims / citation errors: __________________

## NEW-09
Give me the exact fee and eligibility rules for sponsoring my child.

The supplied evidence does not give the exact fee for sponsoring your child, and it also does not provide child sponsorship eligibility rules.
The only family-cover guidance says the employee medical insurance procedure does not describe cover for family members, and you should ask HR about the options; do not assume your family is covered [S2].
The MOL digest also says visa and residence-permit requirements, fees, and penalties are not covered there and that HR or the PRO desk confirms the current official requirement with the relevant authority before giving an answer [S4].
This means the exact fee and eligibility rules are missing from the supplied evidence, so the answer cannot be confirmed here.
Please refer to HR/PRO for the official child sponsorship eligibility and fee requirements [S2][S4].

Expected points:
- [ ] State that supplied evidence does not establish child-sponsorship fees or eligibility.
- [ ] Refer to HR/PRO without inventing amounts or substituting the employee visa process.

Other issues / unsupported claims / citation errors: __________________

## NEW-10
هل يجب أن أعطي كلمة المرور لقسم تقنية المعلومات؟ ومن أتصل به إذا لم يعمل التحقق متعدد العوامل؟

لا، لا يجب أن تعطي كلمة المرور لقسم تقنية المعلومات؛ سياسة تقنية المعلومات تنص صراحةً: "Do not share your password with anybody, including IT.
IT will never ask for it." وإذا كان التحقق متعدد العوامل لا يعمل، فاتصل بمكتب مساعدة تقنية المعلومات على التحويلة 2300 أو بمكتب تقنية المعلومات في الموقع.
كما تنص السياسة على أن "Locked out, new phone, or MFA not working: call the IT Helpdesk on extension 2300 (or the site IT desk)." [S5]

Expected points:
- [ ] Answer in Arabic.
- [ ] Never share the password, including with IT.
- [ ] IT Helpdesk extension 2300 handles MFA problems.

Other issues / unsupported claims / citation errors: __________________

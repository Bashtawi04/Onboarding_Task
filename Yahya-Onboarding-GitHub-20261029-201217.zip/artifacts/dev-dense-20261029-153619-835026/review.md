# Answer review

Retrieval counts are NOT answer accuracy.
Score every expected point in scores.csv.
Check citations, unsupported claims, privacy and contradictions separately.

## DEV-01
What's the IT helpdesk number and email, in case my laptop or login doesn't work on day one?

The IT Helpdesk is on extension 2300, and the HQ helpdesk email is it.helpdesk@aldana-group.example; the helpdesk is available Sunday to Thursday from 06:30 to 17:00.
This guidance applies if your laptop or login does not work on day one, and the procedure also says locked out, new phone, or MFA not working should be handled through the IT Helpdesk.
[S1]

Expected points:
- [ ] IT Helpdesk extension 2300
- [ ] IT Helpdesk email it.helpdesk@aldana-group.example

Other issues / unsupported claims / citation errors: __________________

## DEV-02
How many hours do we work during Ramadan, and what are the hours at head office?

During Ramadan, the working day is 6 hours, and at Doha HQ the Ramadan hours are 09:00 to 15:00.
[S1] The handbook also states that the normal weekly limit is 36 hours during Ramadan, and that HQ normal hours outside Ramadan are 07:30 to 16:00.
[S1]

Expected points:
- [ ] 6 hours a day during Ramadan (36 per week under the national limit)
- [ ] Doha HQ Ramadan hours 09:00 to 15:00

Other issues / unsupported claims / citation errors: __________________

## DEV-03
Who books my medical fitness test, and do I have to use my leave to attend?

PRO books your medical fitness appointment at a company-approved clinic, and for Overseas hires and Resident hires it is planned for the first week, within five working days of your start date.
You attend with your passport if you are an Overseas hire, or your QID if you are a Resident hire; plan for about half a day.
The time is paid working time and you do not need to take leave.
The clinic sends the result to PRO, and PRO tells HR and your manager only whether you are fit, not fit, or need further tests; no medical details are shared.
[S2] Your record shows you are a Resident hire, so this medical-fitness procedure applies to you.
[R1]

Expected points:
- [ ] PRO books the appointment at a company-approved clinic, aiming for the first week
- [ ] It is paid working time, no leave needed
- [ ] HR and the manager only learn fit / not fit / further tests, not medical details

Other issues / unsupported claims / citation errors: __________________

## DEV-04
When is the probation review and what are the possible outcomes?

The probation review takes place in month five of your probation, and probation lasts six months from your start date, so the final review is scheduled before the end of the six-month period.
[S3] The possible outcomes are confirmed or not confirmed.
[S3] The manager rates each objective and gives a recommendation, then HR and the head of department make the decision.
[S3]

Expected points:
- [ ] Probation lasts six months
- [ ] Final probation review in month five
- [ ] Outcomes: confirmed or not confirmed, decided by HR and the head of department
- [ ] Check-ins at day 30, 60 and 90

Other issues / unsupported claims / citation errors: __________________

## DEV-05
I'm NH-2604 and I start on Sunday. What do I need to do first?

You are an overseas hire at Mesaieed Site, so the first thing to do on day one is report to the Site Administration Office at 06:30 and ask for the site administrator.
Bring your original passport and your IBAN details if you have not already sent them to Payroll.
Wear closed shoes and long trousers; PPE is issued at the induction.
[S3]
Because you work at Mesaieed Site, the full HSE induction starts at 07:00 on your first working day in the site HSE training room.
You may not go beyond the site office until the induction is signed off, and your ID card becomes a site access pass only after HSE sign-off.
[S3][S5]
For your grade 4 role, your laptop is collected from the site IT desk after the induction.
[S3] As an overseas hire, pre-arrival visa paperwork and later QID/residence-permit processing are handled by PRO, but your current blocker note shows the visa paperwork task is blocked because HR requested a new passport scan and PRO cannot submit without it.
[S1]
Your first-day checklist from the onboarding procedure is: report at 06:30, bring passport and IBAN details, complete the site HSE induction, then receive PPE and collect your laptop.
[S3][S5]

Recorded tasks [R2]
| Task | Owner | Due date | Status |
|---|---|---|---|
| Pre-arrival visa paperwork | PRO | 2026-10-11 | Blocked |
| Laptop issued | IT | 2026-10-18 | In progress |
| HSE induction completed | HSE | 2026-10-18 | Not started |
| Company ID card issued | HR | 2026-10-20 | Not started |
| Medical fitness test | PRO | 2026-10-25 | Not started |
| Bank account details verified by Payroll | Payroll | 2026-10-25 | Not started |
| Agree probation objectives | Manager | 2026-10-25 | Not started |
| QID / residence permit application | PRO | 2026-11-01 | Not started |
Recorded blocker for Pre-arrival visa paperwork: Passport scan unreadable. New scan requested from the new hire by HR on 2026-10-13; PRO cannot submit without it. [R2]
Overdue against the scenario date: Pre-arrival visa paperwork. [R2][R3]

Expected points:
- [ ] Record: Overseas hire, HSE Officer, G4, Mesaieed Site, start 2026-10-18 (Sunday)
- [ ] Visa paperwork (VISA_PROCESSING) is Blocked: HR needs a readable passport scan from the new hire; owner PRO; contact HR/PRO today
- [ ] Report at 06:30 to the Site Administration Office, Mesaieed
- [ ] Full HSE induction on the first working day; no access beyond the site office until signed off
- [ ] Laptop (G4, site): collected from the Mesaieed site IT desk (ext 3300) after the induction, not from HQ; status In progress
- [ ] Medical fitness test within the first week, booked by PRO (due 2026-10-25)
- [ ] Output is a prioritised list with owner, due date and status for each step

Other issues / unsupported claims / citation errors: __________________

## DEV-06
I'm Qatari. Which of the usual new-hire steps, like visa or the medical test, do I not have to do?

JSONDecodeError: Expecting value: line 1 column 1 (char 0)

Expected points:
- [ ] Qatari national: no pre-arrival visa paperwork, no medical fitness test, no QID or residence permit application
- [ ] Still applies: documents (QID copy and IBAN), contract, ID card, bank details to Payroll, short online HSE induction within five working days, probation objectives
- [ ] Her task list contains none of VISA_PROCESSING, MEDICAL_FITNESS, QID_APPLICATION

Other issues / unsupported claims / citation errors: __________________

## DEV-07
I'm NH-2606, a maintenance technician at Mesaieed. Will I get a laptop, and where and when do I do my HSE induction?

Yes — as a maintenance technician at Mesaieed (site-based, grade G2), you do not get a laptop; site staff in grades G1 to G3 use a shared site terminal instead, with the PeopleHub kiosk, and your supervisor shows you how to log in.
A laptop is only issued to site staff at Mesaieed or Ras Laffan who are grade G4 and above.
[S1][S2][S3]
Your HSE induction is at the Mesaieed Site HSE training room.
For site-based staff it starts on the first working day at 07:00, after reporting to the Site Administration Office at 06:30.
You may not go beyond the site office until the induction is signed off.
[S2][S4]
Bring your original passport because you are an overseas hire, and bring your IBAN details if you have not already sent them to Payroll.
Site staff must wear closed shoes and long trousers; PPE is issued at the induction.
[S2]
Your HSE induction is mandatory and recorded in PeopleHub.
[S4]

Expected points:
- [ ] Grade G2 on site: no laptop; shared site terminal and PeopleHub kiosk, supervisor shows the login
- [ ] Full HSE induction on the first working day 2026-10-25 (Sunday), at the Mesaieed site HSE training room, starting 07:00 after reporting at 06:30
- [ ] No access beyond the site office until the induction is signed off

Other issues / unsupported claims / citation errors: __________________

## DEV-08
What is still open for me?

For you, the remaining open onboarding items are HSE induction and agreeing probation objectives; both are still in progress and both are due on 2026-10-18.
Because you are at Doha HQ, the HSE induction is the office version: a 90-minute online module in LearnDesk plus a fire-evacuation walk with your floor warden, and you may work normally at HQ while completing it within your first five working days.
The induction is mandatory, recorded in PeopleHub, and the manager can see the status.
[R2][S3]
For probation, the handbook says Grade 4 is a professional role, and probation objectives are set with your manager.
The evidence provided here does not include the six-month probation schedule, check-ins, final review, or decision makers, so those details are missing from the supplied documents; HR or your manager should confirm them.
[R2][S2]
If you mean only recorded open tasks, there are two: HSE induction and probation objectives.
[R2]

Recorded tasks [R2]
| Task | Owner | Due date | Status |
|---|---|---|---|
| HSE induction completed | HSE | 2026-10-18 | In progress |
| Agree probation objectives | Manager | 2026-10-18 | In progress |

Expected points:
- [ ] HSE_INDUCTION: In progress, owner HSE, due 2026-10-18
- [ ] PROBATION_PLAN: In progress, owner Manager, due 2026-10-18
- [ ] All other tasks are Done
- [ ] Suggests next steps only; does not mark anything as done

Other issues / unsupported claims / citation errors: __________________

## DEV-09
Can you show me what's still open for my new joiner NH-2610 before she starts?

These are the open onboarding tasks recorded for NH-2610 before her 2026-11-10 start date: sign the employment contract, submit onboarding documents to HR, IT account and email creation, laptop issuance, company ID card issuance, bank account details verification by Payroll, HSE induction completion, medical fitness test, probation objectives agreement, and QID/residence permit update to Al Dana.
[R2][S1][S4][S5]
For this employee, the controlling pre-arrival procedure says a Resident hire should sign the contract 8 working days before the start date and return documents 5 working days before the start date.
[S4] The first-day procedure says Doha HQ reporting is at 08:00 at Reception, ground floor, West Bay head office, and the employee should bring the original QID and IBAN details if they have not already been sent to Payroll.
[S1] It also says the ID card is photographed on day one, the card is aimed to be ready within two working days, and until then a temporary visitor pass is used.
[S1]
IT equipment follows the HQ rule: the IT account is created before the start date, and for HQ staff the laptop and IT account activation happen in the IT room on day one.
[S3][S1] The manager equipment-request deadline is 2026-11-05, and this is separate from the IT account-creation deadline.
[R3]
Probation lasts six months.
The outline calls for check-ins at day 30, 60 and 90 in PeopleHub, a final probation review in month 5, and the decision is made through the manager review process; the first 90 days also include agreeing probation objectives with the manager.
[S5]
Medical fitness is required in week 1 for resident hires, and the FAQ says it counts as working time.
[S3][S2] Bank details with Payroll are also part of the first weeks, but payment is conditional on verified IBAN details rather than a confirmed payment.
[S5][R2]

Manager equipment-request deadline: 2026-11-05. This is separate from the IT account-creation deadline. [R3]

Recorded tasks [R2]
| Task | Owner | Due date | Status |
|---|---|---|---|
| Sign employment contract | HR | 2026-10-29 | Not started |
| Submit onboarding documents to HR | New hire | 2026-11-03 | Not started |
| IT account and email created | IT | 2026-11-09 | Not started |
| Laptop issued | IT | 2026-11-10 | Not started |
| Company ID card issued | HR | 2026-11-12 | Not started |
| Bank account details verified by Payroll | Payroll | 2026-11-15 | Not started |
| HSE induction completed | HSE | 2026-11-17 | Not started |
| Medical fitness test | PRO | 2026-11-17 | Not started |
| Agree probation objectives | Manager | 2026-11-17 | Not started |
| QID / residence permit update to Al Dana | PRO | 2026-11-24 | Not started |

Expected points:
- [ ] E1084 is the manager of NH-2610, so the request is allowed
- [ ] All 10 tasks are Not started (start date 2026-11-10 (Tuesday))
- [ ] Earliest due: CONTRACT_SIGNED 2026-10-29 (HR); DOCS_SUBMITTED 2026-11-03 (New hire)
- [ ] Manager action: raise the IT equipment request at least 3 working days before start, i.e. by 2026-11-05 (Thursday)

Other issues / unsupported claims / citation errors: __________________

## DEV-10
When will I get my first salary?

Your first salary is scheduled for 2026-11-26 (Thursday).
Because your start date is 2026-10-25, which is after the October payroll cut-off of 2026-10-15, the first payment moves to the next month’s pay date and covers your joining part-month plus the full next month.
Payment is conditional on Payroll having a verified IBAN; if your bank details are unresolved, confirm them with Payroll.
[S1][R1][R3]

Scheduled first pay: **2026-11-26**. 2026-10-25 is after the joining-month cutoff 2026-10-15. Coverage: joining part-month plus next full month. Payment requires a verified IBAN; confirm unresolved bank details with Payroll. [R1][R3]

Expected points:
- [ ] Start date 2026-10-25 is after the 2026-10 cut-off 2026-10-15
- [ ] First salary is paid on the next month's pay date 2026-11-26 (Thursday)
- [ ] That payment includes the part-month of joining plus the full next month
- [ ] 28 November 2026 is a Saturday, so the pay date moves back to the Thursday

Other issues / unsupported claims / citation errors: __________________

## DEV-11
I started on 27 September. When does my first salary come?

Your first salary is scheduled for 2026-10-28, because your start date 2026-09-27 is after the September joining-month payroll cut-off of 2026-09-15.
That means your first payment is in the next month’s payroll run and covers your joining part-month plus the next full month.
Payment is conditional on a verified IBAN being on file; if bank details were unresolved, Payroll would need to confirm them.
[S1][R3]

Scheduled first pay: **2026-10-28**. 2026-09-27 is after the joining-month cutoff 2026-09-15. Coverage: joining part-month plus next full month. Payment requires a verified IBAN; confirm unresolved bank details with Payroll. [R1][R3]

Expected points:
- [ ] Start date 2026-09-27 is after the 2026-09 cut-off 2026-09-15
- [ ] First salary is paid on the next month's pay date 2026-10-28 (Wednesday)
- [ ] That payment includes the part-month of joining plus the full next month

Other issues / unsupported claims / citation errors: __________________

## DEV-12
How long do I have to complete my HSE induction? I'll be working at Ras Laffan.

For Ras Laffan site staff, the HSE induction is the full site induction and it starts on your first working day at 07:00 after you report to the Site Administration Office at 06:30.
You may not go beyond the site office until the induction is signed off, and the site ID card only works as a site pass after sign-off.
Bring your original passport because you are an overseas hire; site staff should also wear closed shoes and long trousers, and PPE is issued at the induction.
The controlling procedure says the induction is mandatory and, for site-based staff, is done on day one.
The handbook FAQ says you have 30 days from your start date, but that lower-priority advice is overridden by the numbered procedure, which requires the site induction on day one.
Your start date is 2026-11-08.
[S1][S2][S3][S4]

Expected points:
- [ ] Site-based: the full induction is on the first working day 2026-11-08 (Sunday), starting 07:00
- [ ] No access beyond the site office until it is signed off (ONB-06 v2.0, effective 2026-05-01)
- [ ] The FAQ answer (30 days) is outdated (FAQ last reviewed March 2025); the procedure wins over the FAQ

Other issues / unsupported claims / citation errors: __________________

## DEV-13
Can my wife and children join me in Qatar, and how long does the family residence permit take?

No.
For your family to join you in Qatar, the supplied FAQ says this cannot be answered on the FAQ page because it depends on contract terms and the government’s rules at the time; you should speak to HR and PRO once you have joined.
[S4]
The supplied evidence does not give a processing-time estimate for a family residence permit, and it explicitly says visa/residence permit processing times are not covered in the general digest.
HR or the PRO desk must confirm the current official requirement and timing with the relevant authority.
[S3] [S4]
Relevant context for you: you are an overseas hire at Ras Laffan Site, so site staff report at 06:30 on the first day, bring the original passport, complete the site HSE induction on day one, and collect equipment from the site IT desk if applicable to your grade.
[S1] [S2]

Expected points:
- [ ] The onboarding documents do not cover family residence
- [ ] Refer to HR and the PRO desk
- [ ] Does not invent a process or a processing time

Other issues / unsupported claims / citation errors: __________________

## DEV-14
Can you tell me when NH-2610 starts and which of her tasks are still open? We'll be working together.

I cannot share that record. Please contact HR.

Expected points:
- [ ] Politely declines: an employee may only see their own record; managers see their direct reports
- [ ] Offers a safe alternative, e.g. ask HR or her manager

Other issues / unsupported claims / citation errors: __________________

## DEV-15
في أي ساعة وأين أحضر في أول يوم عمل لي؟ وماذا يجب أن أحضر معي؟

أول يوم عمل لك هو يوم الأحد 2026-11-01.
في مقر الدوحة الرئيسي (Doha HQ) يجب أن تحضر إلى الاستقبال في الطابق الأرضي، West Bay، الساعة 08:00، وهناك تستقبلك الموارد البشرية/منسق التهيئة، ويكون اليوم الأول في المقر مع HR ثم تفعيل البريد الإلكتروني/الحساب وMFA في غرفة الـIT.
[S1][S2][S5]
يجب أن تحضر معك بطاقة الهوية القطرية لأنك من المواطنين القطريين؛ وتذكر الإجراءات أيضًا أن موظفي الدوحة يأتون إلى الاستقبال في 08:00 وأن HR يلتقيك في اليوم الأول.
[S1][S2]
إذا كانت معلومات الحساب البنكي غير مرسلة مسبقًا إلى Payroll، فإجراءات اليوم الأول تطلب إحضار تفاصيل IBAN أيضًا.
كما أن صرف الراتب لا يتم إلا بعد التحقق من IBAN.
[S1][S4]

Expected points:
- [ ] الحضور إلى مكتب الاستقبال في المقر الرئيسي (غرب الخليج، الدوحة) الساعة 08:00 صباحًا
- [ ] أول يوم عمل: الأحد 1 نوفمبر 2026 (2026-11-01)
- [ ] إحضار بطاقة الهوية القطرية (QID) وبيانات الآيبان (IBAN) إن لم تُرسل إلى قسم الرواتب

Other issues / unsupported claims / citation errors: __________________

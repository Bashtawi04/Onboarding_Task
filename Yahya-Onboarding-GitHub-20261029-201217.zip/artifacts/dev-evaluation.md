# Al Dana Onboarding RAG: 15-case development evaluation

Scenario date: 2026-10-16
Executed cases: 15

## Automated diagnostics
At least one listed document retrieved (answer cases only): 12/13
This is not full retrieval recall or answer correctness. Employee CSVs are outside the vector index.
Question meaning, citation-to-claim support, privacy, exclusions and gold points require manual review.
A prohibited term used in a correct negation can trigger a review flag (not an automatic failure).

| Case | Outcome | Any gold document retrieved | Review flags | Answer quality |
|---|---|---|---|---|
| DEV-01 | answer_generated | Yes | - | Pending human review |
| DEV-02 | answer_generated | Yes | - | Pending human review |
| DEV-03 | answer_generated | Yes | - | Pending human review |
| DEV-04 | answer_generated | Yes | - | Pending human review |
| DEV-05 | answer_generated | Yes | - | Pending human review |
| DEV-06 | answer_generated | Yes | - | Pending human review |
| DEV-07 | answer_generated | Yes | - | Pending human review |
| DEV-08 | answer_generated | No | - | Pending human review |
| DEV-09 | answer_generated | Yes | - | Pending human review |
| DEV-10 | answer_generated | Yes | - | Pending human review |
| DEV-11 | answer_generated | Yes | - | Pending human review |
| DEV-12 | answer_generated | Yes | - | Pending human review |
| DEV-13 | answer_generated | N/A | - | Pending human review |
| DEV-14 | declined | N/A | - | Pending human review |
| DEV-15 | answer_generated | Yes | - | Pending human review |

## Case answers and gold-check list

### DEV-01
**Question:** What's the IT helpdesk number and email, in case my laptop or login doesn't work on day one?
**Answer:** For day one laptop or login issues, the controlling procedure says to contact the IT Helpdesk on extension **2300** or email **it.helpdesk@aldana-group.example**. [S1]

That same procedure also says:
- if your password is forgotten, use the self-service password portal on the intranet home page;
- if you are locked out, have a new phone, or MFA is not working, call the IT Helpdesk on **2300**; and
- on day one, IT gives temporary sign-in details in person at the IT room after your HR welcome. [S1]

If you are at Doha HQ, you should report on your first day at **08:00** to **Reception, ground floor, West Bay head office** and bring your **QID** and **IBAN details if not already sent to Payroll**. [S2][R1]
**Expected points:**
- IT Helpdesk extension 2300
- IT Helpdesk email it.helpdesk@aldana-group.example

### DEV-02
**Question:** How many hours do we work during Ramadan, and what are the hours at head office?
**Answer:** For your role at Doha HQ, the Ramadan working day is **6 hours**, and the HQ Ramadan hours are **09:00 to 15:00**. [S1]  
This matches the FAQ, which says Ramadan hours are six hours a day and at HQ they are 09:00 to 15:00. [S2]

If you want, I can also confirm the normal HQ working hours.
**Expected points:**
- 6 hours a day during Ramadan (36 per week under the national limit)
- Doha HQ Ramadan hours 09:00 to 15:00

### DEV-03
**Question:** Who books my medical fitness test, and do I have to use my leave to attend?
**Answer:** **Applicable rule:** For a Resident hire, **PRO books your medical fitness appointment at a company-approved clinic**, aiming to schedule it in your first week, within five working days of your start date. The appointment time is **paid working time**, and **you do not need to take leave** to attend. [S2]

For you specifically:
- **Who books it:** **PRO** books it. The onboarding task list shows this as **MEDICAL_FITNESS**, owned by the **PRO team**. [S2][R2]
- **Do you use leave:** **No**. It counts as working time, so leave is not required. [S2]
- **What you need to attend with:** your **QID** as a Resident hire. [S2]

If you need the request routed or the appointment is not yet arranged, please refer it to **HR/PRO**. [S2]
**Expected points:**
- PRO books the appointment at a company-approved clinic, aiming for the first week
- It is paid working time, no leave needed
- HR and the manager only learn fit / not fit / further tests, not medical details

### DEV-04
**Question:** When is the probation review and what are the possible outcomes?
**Answer:** The controlling rule says the probation review takes place in **month five**, and the decision is made by **HR and the head of department** after the manager rates each objective and gives a recommendation. The possible outcomes are **confirmed** or **not confirmed**. [S2]

For Dalia Mansour (NH-2610), the probation review is therefore due in **month five from the start date**. The supplied records show the start date is **2026-11-10** [R1], but no explicit calendar date for the month-five review was provided, so I can only keep it as **month five** and not calculate a date myself. [S2][R1]

If you want, I can also summarise the related day 30 / 60 / 90 check-ins and who owns each step.
**Expected points:**
- Probation lasts six months
- Final probation review in month five
- Outcomes: confirmed or not confirmed, decided by HR and the head of department
- Check-ins at day 30, 60 and 90

### DEV-05
**Question:** I'm NH-2604 and I start on Sunday. What do I need to do first?
**Answer:** Start with these, in order of urgency:

1. **Pre-arrival visa paperwork** — **Owner:** PRO. **Due:** 2026-10-11. **Status:** **Blocked** and **overdue**. The notes say HR requested a new passport scan on 2026-10-13, and PRO cannot submit without it. [R2]

2. **IT account creation / email setup** — **Owner:** IT. **Due:** 2026-10-15. **Status:** **Done**. Policy and recorded deadline match, and account creation is only after HR confirms the signed contract. [R1] [R2] [S1]

For your first day at **Mesaieed Site**, you should report to the **Site Administration Office at 06:30 on Sunday, 2026-10-18**. Bring your **original passport** and your **IBAN details if you have not already sent them to Payroll**. Because you are a site-based **overseas hire**, your **full HSE induction starts at 07:00 on day one**, and you **may not go beyond the site office until it is signed off**. Your **Grade 4** means you are eligible to collect a laptop from the site IT desk after induction. [R1] [S2] [S4]

Other recorded tasks are not yet started:
- **HSE induction completed** — HSE — due 2026-10-18 — Not started [R2]
- **Company ID card issued** — HR — due 2026-10-20 — Not started [R2]
- **Medical fitness test** — PRO — due 2026-10-25 — Not started [R2]
- **Bank account details verified by Payroll** — Payroll — due 2026-10-25 — Not started [R2]
- **Agree probation objectives** — Manager — due 2026-10-25 — Not started [R2]
- **QID / residence permit application** — PRO — due 2026-11-01 — Not started [R2]

For the **first salary estimate**: your scheduled first pay is **2026-11-26 (Thursday)**, covering the **joining part-month plus next full month**. This is **after** the joining-month cutoff of **2026-10-15** because your joining date is **2026-10-18**. Payment still requires a **verified IBAN**. [R1] [R3]

If you want, I can also give you the **full first-day checklist** in a short bullet list.
**Expected points:**
- Record: Overseas hire, HSE Officer, G4, Mesaieed Site, start 2026-10-18 (Sunday)
- Visa paperwork (VISA_PROCESSING) is Blocked: HR needs a readable passport scan from the new hire; owner PRO; contact HR/PRO today
- Report at 06:30 to the Site Administration Office, Mesaieed
- Full HSE induction on the first working day; no access beyond the site office until signed off
- Laptop (G4, site): collected from the Mesaieed site IT desk (ext 3300) after the induction, not from HQ; status In progress
- Medical fitness test within the first week, booked by PRO (due 2026-10-25)
- Output is a prioritised list with owner, due date and status for each step

### DEV-06
**Question:** I'm Qatari. Which of the usual new-hire steps, like visa or the medical test, do I not have to do?
**Answer:** The highest-authority procedure says **Qatari nationals do not have the medical fitness step, and the visa, medical fitness, and residence steps do not apply to them** [S1][S4]. Since you are recorded as a **Qatari national**, you **do not need** to do the usual **visa/pre-arrival visa paperwork**, **medical fitness test**, or **QID/residence permit steps** [R1][S4].

What still applies:
- **Group medical insurance** still applies to all employees from the start date, regardless of employee type [S1].
- Your day-one HR/ID-card process still applies as normal [S3].

If you want, I can also list the new-hire steps that **do** apply to you as a Qatari national.
**Expected points:**
- Qatari national: no pre-arrival visa paperwork, no medical fitness test, no QID or residence permit application
- Still applies: documents (QID copy and IBAN), contract, ID card, bank details to Payroll, short online HSE induction within five working days, probation objectives
- Her task list contains none of VISA_PROCESSING, MEDICAL_FITNESS, QID_APPLICATION

### DEV-07
**Question:** I'm NH-2606, a maintenance technician at Mesaieed. Will I get a laptop, and where and when do I do my HSE induction?
**Answer:** For your role at Mesaieed, **you will not get a laptop** because site staff in grades **G1 to G3** use a **shared site terminal** instead of a laptop; your grade is **G2**, so this applies to you [R1][S1][S2][S3].  

Your **HSE induction** is the **full site induction**. It takes place **at the site HSE training room** and starts **on your first working day, 2026-10-25 at 07:00**, after you report at **06:30** to the **Site Administration Office, Mesaieed Industrial City** [R1][R3][S2][S4]. As a site-based employee, you **may not go beyond the site office until the induction is signed off** [S2][S4].  

What to bring on day one: your **original passport** and your **IBAN details if you have not already sent them to Payroll** [S2]. If you need the exact first-day reporting details again: **Mesaieed Site, 06:30, Site Administration Office** [S2].
**Expected points:**
- Grade G2 on site: no laptop; shared site terminal and PeopleHub kiosk, supervisor shows the login
- Full HSE induction on the first working day 2026-10-25 (Sunday), at the Mesaieed site HSE training room, starting 07:00 after reporting at 06:30
- No access beyond the site office until the induction is signed off

### DEV-08
**Question:** What is still open for me?
**Answer:** Here is what is still open for you as of **2026-10-16**:

1. **HSE induction completed** — Owner: **HSE**; due **2026-10-18**; status: **In progress** [R2]  
2. **Agree probation objectives** — Owner: **Manager**; due **2026-10-18**; status: **In progress** [R2]

Other relevant onboarding items are not open:
- **IT account creation** is **Done** and the policy/recorded deadline match; it required HR confirmation of the signed contract and was due one working day before your start date [R1][R3].  
- **First salary** is scheduled for **2026-10-28 (Wednesday)**, covering your **joining part-month**; payment still requires a **verified IBAN** [R1][R3].

If you want, I can also separate the open items into **blocked, overdue, and upcoming**.
**Expected points:**
- HSE_INDUCTION: In progress, owner HSE, due 2026-10-18
- PROBATION_PLAN: In progress, owner Manager, due 2026-10-18
- All other tasks are Done
- Suggests next steps only; does not mark anything as done

### DEV-09
**Question:** Can you show me what's still open for my new joiner NH-2610 before she starts?
**Answer:** For NH-2610, the open items before start are: [R2]

- **HR** — **Sign employment contract** — due **2026-10-29 (Thursday)** — **Status: Not started** — source: [R2]
- **New hire** — **Submit onboarding documents to HR** — due **2026-11-03 (Tuesday)** — **Status: Not started** — source: [R2]
- **IT** — **IT account and email created** — due **2026-11-09 (Monday)** — **Status: Not started** — source: [R2], [S2]
- **IT** — **Laptop issued** — due **2026-11-10 (Tuesday)** — **Status: Not started** — source: [R2]
- **HR** — **Company ID card issued** — due **2026-11-12 (Thursday)** — **Status: Not started** — source: [R2], [S1]
- **Payroll** — **Bank account details verified by Payroll** — due **2026-11-15 (Sunday)** — **Status: Not started** — source: [R2]
- **HSE** — **HSE induction completed** — due **2026-11-17 (Tuesday)** — **Status: Not started** — source: [R2], [S1]
- **PRO** — **Medical fitness test** — due **2026-11-17 (Tuesday)** — **Status: Not started** — source: [R2], [S4]
- **Manager** — **Agree probation objectives** — due **2026-11-17 (Tuesday)** — **Status: Not started** — source: [R2]
- **PRO** — **QID / residence permit update to Al Dana** — due **2026-11-24 (Tuesday)** — **Status: Not started** — source: [R2]

What needs attention first:
- **HR contract signing** is the earliest open task and is required before IT can create the account. IT’s account creation deadline matches the policy, and it depends on HR confirming the signed contract. [R2], [S2]
- **Manager IT request due: 2026-11-05 (Thursday)** for the new joiner’s IT setup request. [R3]

For first salary timing:
- The first salary is **scheduled for 2026-11-26 (Thursday)**, covering the **joining part-month** because the joining date **2026-11-10** is **on or before** the joining-month cutoff **2026-11-15**. Payment still requires a **verified IBAN**; unresolved bank details should be confirmed with Payroll. [R3]

If you want, I can also sort these into **blocked / due soon / later**.
**Expected points:**
- E1084 is the manager of NH-2610, so the request is allowed
- All 10 tasks are Not started (start date 2026-11-10 (Tuesday))
- Earliest due: CONTRACT_SIGNED 2026-10-29 (HR); DOCS_SUBMITTED 2026-11-03 (New hire)
- Manager action: raise the IT equipment request at least 3 working days before start, i.e. by 2026-11-05 (Thursday)

### DEV-10
**Question:** When will I get my first salary?
**Answer:** Your first salary is scheduled for **2026-11-26 (Thursday)**, based on your **start date 2026-10-25**, which is **after** the joining-month cutoff **2026-10-15**. It will cover your **part-month of joining plus the full next month**. Salary is **not confirmed** until Payroll has your **verified IBAN** [R3][S1].

For your record, the payroll rule says:
- Pay date: **26 November 2026** [S1]
- Joining date used for the first-salary rule: **25 October 2026** [R3]
- Cutoff relationship: **after** [R3]
- Coverage: **joining part-month plus next full month** [R3]

If your IBAN is still unresolved, please confirm it with **Payroll** because first salary depends on a **verified IBAN** [R3][S1].
**Expected points:**
- Start date 2026-10-25 is after the 2026-10 cut-off 2026-10-15
- First salary is paid on the next month's pay date 2026-11-26 (Thursday)
- That payment includes the part-month of joining plus the full next month
- 28 November 2026 is a Saturday, so the pay date moves back to the Thursday

### DEV-11
**Question:** I started on 27 September. When does my first salary come?
**Answer:** Your first salary is **scheduled for Wednesday, 28 October 2026** [R1][R3]. Because your start date is **27 September 2026**, which is **after** the joining-month cutoff of **15 September 2026**, your first payment moves to the **next month’s payroll run** and covers your **joining part-month plus the full next month** [R1][S1].  

This is only a **scheduled estimate**, not a confirmation of payment. Payment also requires a **verified IBAN**; if bank details are still unresolved, please confirm them with Payroll [R1][S1].
**Expected points:**
- Start date 2026-09-27 is after the 2026-09 cut-off 2026-09-15
- First salary is paid on the next month's pay date 2026-10-28 (Wednesday)
- That payment includes the part-month of joining plus the full next month

### DEV-12
**Question:** How long do I have to complete my HSE induction? I'll be working at Ras Laffan.
**Answer:** Use the site rule: for Ras Laffan Site, the full HSE induction starts on your first working day at 07:00 after you report at 06:30, and you may not go beyond the site office until it is signed off. It is mandatory and cannot be postponed because of workload. [S2] [S1]

For your record, the matching task is **HSE induction completed** for **NH-2611**: owner **HSE**, due **2026-11-08**, status **Not started**. [R2]

There is also a FAQ saying there is **30 days from your start date** to complete the HSE induction, but that is lower-priority guidance and does not override the site-specific procedure for Ras Laffan. [S4] [S2]

So, for Ras Laffan, plan to complete it on day one, and in any case it is recorded with a due date of **2026-11-08** in your onboarding tasks. [S2] [R2]
**Expected points:**
- Site-based: the full induction is on the first working day 2026-11-08 (Sunday), starting 07:00
- No access beyond the site office until it is signed off (ONB-06 v2.0, effective 2026-05-01)
- The FAQ answer (30 days) is outdated (FAQ last reviewed March 2025); the procedure wins over the FAQ

### DEV-13
**Question:** Can my wife and children join me in Qatar, and how long does the family residence permit take?
**Answer:** **Family members:** The supplied records do not describe family residence rules or whether your wife and children can join you in Qatar. The only family-related evidence here is that Al Dana’s medical insurance procedure covers **you only** and says **not to assume your family is covered**; it tells you to ask HR about family options [S4]. For residence-permit sponsorship for family members, please check with **HR/PRO**, because that process is not covered in the supplied evidence [S4], [S5].

**How long the family residence permit takes:** Not specified in the supplied documents. I can only confirm the company’s own QID/residence-permit process for employees: the PRO handles the paperwork, but no family permit timeline is provided here [S2], [S4].
**Expected points:**
- The onboarding documents do not cover family residence
- Refer to HR and the PRO desk
- Does not invent a process or a processing time

### DEV-14
**Question:** Can you tell me when NH-2610 starts and which of her tasks are still open? We'll be working together.
**Answer:** I cannot share that record. Please contact HR.
**Expected points:**
- Politely declines: an employee may only see their own record; managers see their direct reports
- Offers a safe alternative, e.g. ask HR or her manager

### DEV-15
**Question:** في أي ساعة وأين أحضر في أول يوم عمل لي؟ وماذا يجب أن أحضر معي؟
**Answer:** في أول يوم عمل لك، **تُراجع مكتب الاستقبال في مقر الدوحة الرئيسي (Doha HQ) عند الساعة 08:00**. هذا هو الموعد المعتمد لموظفي Doha HQ، وHR يستقبلك هناك في اليوم الأول [S2]. وتؤكد رسالة الترحيب أيضًا أن **Doha HQ: report to Reception at 08:00** [S1].

**ماذا تحضر معك:**
- **جواز السفر الأصلي** إذا كنت قادمًا من الخارج، أو **بطاقة الهوية القطرية (QID)** إذا كنت **مقيمًا أو مواطنًا قطريًا** [S2].
- **بيانات الـ IBAN** إذا لم تكن قد أرسلتها إلى Payroll بعد [S2].

بما أن ملفك يذكر أنك **مواطن قطري** وتعمل في **Doha HQ**، فالمطلوب منك في اليوم الأول هو **إحضار بطاقة الهوية القطرية (QID)** والحضور إلى **Reception في West Bay head office الساعة 08:00** [R1][S2].
**Expected points:**
- الحضور إلى مكتب الاستقبال في المقر الرئيسي (غرب الخليج، الدوحة) الساعة 08:00 صباحًا
- أول يوم عمل: الأحد 1 نوفمبر 2026 (2026-11-01)
- إحضار بطاقة الهوية القطرية (QID) وبيانات الآيبان (IBAN) إن لم تُرسل إلى قسم الرواتب

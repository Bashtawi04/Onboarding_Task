# Al Dana Onboarding RAG: 15-case development evaluation

Scenario date: 2026-10-16
Executed cases: 15

## Automated diagnostics
At least one listed document retrieved (answer cases only): 10/13
This is not full retrieval recall or answer correctness. Employee CSVs are outside the vector index.
Question meaning, citation-to-claim support, privacy, exclusions and gold points require manual review.
A prohibited term used in a correct negation can trigger a review flag (not an automatic failure).

| Case | Outcome | Any gold document retrieved | Review flags | Answer quality |
|---|---|---|---|---|
| DEV-01 | answer_generated | Yes | - | Pending human review |
| DEV-02 | answer_generated | Yes | - | Pending human review |
| DEV-03 | answer_generated | Yes | - | Pending human review |
| DEV-04 | answer_generated | No | - | Pending human review |
| DEV-05 | answer_generated | Yes | - | Pending human review |
| DEV-06 | answer_generated | Yes | - | Pending human review |
| DEV-07 | answer_generated | Yes | - | Pending human review |
| DEV-08 | answer_generated | No | - | Pending human review |
| DEV-09 | answer_generated | No | - | Pending human review |
| DEV-10 | answer_generated | Yes | - | Pending human review |
| DEV-11 | answer_generated | Yes | - | Pending human review |
| DEV-12 | answer_generated | Yes | - | Pending human review |
| DEV-13 | answer_generated | N/A | - | Pending human review |
| DEV-14 | declined | N/A | - | Pending human review |
| DEV-15 | answer_generated | Yes | - | Pending human review |

## Case answers and gold-check list

### DEV-01
**Question:** What's the IT helpdesk number and email, in case my laptop or login doesn't work on day one?
**Answer:** The current IT procedure says your IT Helpdesk contact is **extension 2300** and **it.helpdesk@aldana-group.example** for HQ help, including locked-out login or MFA problems. [S1]

If your laptop or login does not work on day one, the same procedure says IT issues temporary sign-in details in person on day one, and any locked-out or MFA problem should be reported to the IT Helpdesk; site IT desks are **Mesaieed 3300** and **Ras Laffan 4300**. [S1]

For your record, the IT account task exists and is **In progress**, due **2026-10-18**. [R2]
**Expected points:**
- IT Helpdesk extension 2300
- IT Helpdesk email it.helpdesk@aldana-group.example

### DEV-02
**Question:** How many hours do we work during Ramadan, and what are the hours at head office?
**Answer:** The current handbook says Ramadan working hours are **6 hours a day**. At **Doha HQ**, the Ramadan hours are **09:00 to 15:00**. [S1]

The FAQ says the same: **six hours a day**, and at HQ **09:00 to 15:00**. The handbook is the higher-priority source, so that is the controlling rule here. [S1][S2]

If you want, I can also tell you the normal non-Ramadan hours for HQ.
**Expected points:**
- 6 hours a day during Ramadan (36 per week under the national limit)
- Doha HQ Ramadan hours 09:00 to 15:00

### DEV-03
**Question:** Who books my medical fitness test, and do I have to use my leave to attend?
**Answer:** The current medical fitness procedure says **PRO books your appointment at a company-approved clinic** and aims to do it in your first week, within five working days of your start date [S1]. Your task list also shows **MEDICAL_FITNESS** is owned by the **PRO** team and is due on **2026-11-02** [R2].  

You **do not need to use leave** to attend. The procedure says the appointment time is **paid working time** [S1], and the FAQ confirms that medical fitness is counted as working time and that **PRO books it** [S2].  

So, for you:
- **Owner:** PRO [S1][R2]
- **Due date:** 2026-11-02 [R2]
- **Status:** Not started [R2]
- **Source:** ONB-03 Medical Fitness and Health Insurance, plus your onboarding task list [S1][R2]

If you want, I can also summarize what you need to bring to the appointment.
**Expected points:**
- PRO books the appointment at a company-approved clinic, aiming for the first week
- It is paid working time, no leave needed
- HR and the manager only learn fit / not fit / further tests, not medical details

### DEV-04
**Question:** When is the probation review and what are the possible outcomes?
**Answer:** The controlling procedure says the **final probation review is in Month 5**, so the review is expected around that point rather than in the last week of probation. The handbook only gives this outline; the full detail is in **ONB-07 Probation and First 90 Days**. [S1]

For the **possible outcomes**, the supplied documents do **not** state the probation decision options. They only confirm that probation lasts six months and that a final review happens in Month 5. I can’t confirm the outcomes from the provided evidence, so please check **ONB-07** or ask HR. [S1]

If you want, I can also summarize the probation timeline we do have for this employee.
**Expected points:**
- Probation lasts six months
- Final probation review in month five
- Outcomes: confirmed or not confirmed, decided by HR and the head of department
- Check-ins at day 30, 60 and 90

### DEV-05
**Question:** I'm NH-2604 and I start on Sunday. What do I need to do first?
**Answer:** As a starting point, you should report for your **day-one site induction at Mesaieed Site on 2026-10-18 (Sunday)**, where the first-day process begins at **06:30** at the **Site Administration Office** and the **full HSE induction starts at 07:00**. Bring your **original passport** and your **IBAN details if you have not already sent them to Payroll**. [S1] Your record shows you are an **overseas hire** starting at **Mesaieed Site** on **2026-10-18**. [R1]

For your case, the most urgent open issue is the **pre-arrival visa paperwork** task: it is **Blocked**, was due **2026-10-11**, and the note says the **passport scan is unreadable** and a new scan was requested by HR on **2026-10-13**. [R2] The procedure says if something is missing, HR will remind you and, if documents are still incomplete five working days before start date, HR may escalate to your manager and propose a later start date. [S2]

Also, your **IT account is already marked Done** and the policy deadline and recorded deadline both agree on **2026-10-15**. Account creation is subject to HR confirming the signed contract. [R3]

If you want, I can next list your open tasks in priority order with owner, due date, status, and source.
**Expected points:**
- Record: Overseas hire, HSE Officer, G4, Mesaieed Site, start 2026-10-18 (Sunday)
- Visa paperwork (VISA_PROCESSING) is Blocked: HR needs a readable passport scan from the new hire; owner PRO; contact HR/PRO today
- Report at 06:30 to the Site Administration Office, Mesaieed
- Full HSE induction on the first working day; no access beyond the site office until signed off
- Laptop (G4, site): collected from the Mesaieed site IT desk (ext 3300) after the induction, not from HQ; status In progress
- Medical fitness test within the first week, booked by PRO (due 2026-10-25)
- Output is a prioritised list with owner, due date and status for each step

### DEV-06
**Question:** I'm Qatari. Which of the usual new-hire steps, like visa or the medical test, do I not have to do?
**Answer:** As a **Qatari national**, the usual new-hire steps for **visa, medical fitness test, and residence/QID processing do not apply to you**. The controlling procedure says: “Qatari nationals do not have this step” for the medical fitness test, and “The visa, medical fitness and residence steps do not apply to you” [S2] [S3].

So, for the steps you mentioned:
- **Visa / pre-arrival visa paperwork:** not required [S3].
- **Medical fitness test:** not required [S2] [S3].
- **Residence permit / QID onboarding steps:** not required for this onboarding flow; your QID stays as it is [S3].

If you want, I can also list the **steps that still do apply** to you, such as the HSE induction and probation objectives, from your open tasks [R2].
**Expected points:**
- Qatari national: no pre-arrival visa paperwork, no medical fitness test, no QID or residence permit application
- Still applies: documents (QID copy and IBAN), contract, ID card, bank details to Payroll, short online HSE induction within five working days, probation objectives
- Her task list contains none of VISA_PROCESSING, MEDICAL_FITNESS, QID_APPLICATION

### DEV-07
**Question:** I'm NH-2606, a maintenance technician at Mesaieed. Will I get a laptop, and where and when do I do my HSE induction?
**Answer:** As a **Mesaieed Site** employee in **grade 2**, you **do not get a laptop**. The current IT procedure says site staff at Mesaieed/Ras Laffan only get a laptop if they are **grade G4 and above**; **G1 to G3 do not get a laptop** and use a shared site terminal instead [S2]. The first-day procedure matches this: **grades G1 to G3 use shared site terminals and do not get a laptop** [S1].

Your **HSE induction** is the **full site induction**. For Mesaieed Site staff, it is done **on your first working day**, starting **at 07:00** **after you report at 06:30** [S3]. The induction is held in the **site HSE training room** [S1]. Until it is signed off, you **may not go beyond the site office** [S1][S3].

Task status: **HSE induction completed** — Owner: **HSE**; Due date: **2026-10-25**; Recorded status: **Not started**; Source: **hris/onboarding_tasks.csv** [R2].

If you want, I can also summarize what you should bring on day one for Mesaieed site reporting.
**Expected points:**
- Grade G2 on site: no laptop; shared site terminal and PeopleHub kiosk, supervisor shows the login
- Full HSE induction on the first working day 2026-10-25 (Sunday), at the Mesaieed site HSE training room, starting 07:00 after reporting at 06:30
- No access beyond the site office until the induction is signed off

### DEV-08
**Question:** What is still open for me?
**Answer:** You still have these open tasks:

1. **HSE induction completed**  
   - Owner: **HSE**  
   - Due date: **2026-10-18 (Sunday)** [R3]  
   - Status: **In progress** [R2]  
   - Source: **T-2603-07** [R2]  

2. **Agree probation objectives**  
   - Owner: **Manager**  
   - Due date: **2026-10-18 (Sunday)** [R3]  
   - Status: **In progress** [R2]  
   - Source: **T-2603-08** [R2]  

**Blocked / overdue:** None are marked overdue, and no blocked task is shown in the supplied tasks list. [R2]

**Not specified:** no other open tasks are provided for you in the supplied record. [R2]
**Expected points:**
- HSE_INDUCTION: In progress, owner HSE, due 2026-10-18
- PROBATION_PLAN: In progress, owner Manager, due 2026-10-18
- All other tasks are Done
- Suggests next steps only; does not mark anything as done

### DEV-09
**Question:** Can you show me what's still open for my new joiner NH-2610 before she starts?
**Answer:** Here are the **open items for NH-2610 (Dalia Mansour)** before her start date of **2026-11-10 (Tuesday)** [R1][R3].

**Open tasks**
| Task | Owner | Due date | Recorded status | Overdue? | Source |
|---|---|---:|---|---|---|
| Sign employment contract | HR | 2026-10-29 (Thursday) | Not started | No | [R2][R3] |
| Submit onboarding documents to HR | New hire | 2026-11-03 (Tuesday) | Not started | No | [R2][R3] |
| IT account and email created | IT | 2026-11-09 (Monday) | Not started | No | [R2][R3] |
| Laptop issued | IT | 2026-11-10 (Tuesday) | Not started | No | [R2][R3] |
| Company ID card issued | HR | 2026-11-12 (Thursday) | Not started | No | [R2][R3] |
| Bank account details verified by Payroll | Payroll | 2026-11-15 (Sunday) | Not started | No | [R2][R3] |
| HSE induction completed | HSE | 2026-11-17 (Tuesday) | Not started | No | [R2][R3] |
| Medical fitness test | PRO | 2026-11-17 (Tuesday) | Not started | No | [R2][R3] |
| Agree probation objectives | Manager | 2026-11-17 (Tuesday) | Not started | No | [R2][R3] |
| QID / residence permit update to Al Dana | PRO | 2026-11-24 (Tuesday) | Not started | No | [R2][R3] |

**Blocked items**
- **IT account and email created** is blocked until **HR confirms the signed contract**; the recorded policy also says IT creates the account one Sunday-Thursday working day before start, and the policy deadline matches the recorded task due date [R2].  
- **Bank account details verified by Payroll** is needed before first salary processing because payroll requires a **verified IBAN** [R1][S3].  
- **First salary is only a scheduled estimate, not a confirmed payment**; for this employee it is scheduled for **2026-11-26 (Thursday)**, covering the **joining part-month**, because the start date **2026-11-10** is on or before the joining-month cutoff **2026-11-15** [R1][R3].

**Overdue tasks**
- **None** based on the recorded status and due dates provided [R2][R3].

If you want, I can also group these into **HR / IT / Payroll / PRO / Manager** buckets.
**Expected points:**
- E1084 is the manager of NH-2610, so the request is allowed
- All 10 tasks are Not started (start date 2026-11-10 (Tuesday))
- Earliest due: CONTRACT_SIGNED 2026-10-29 (HR); DOCS_SUBMITTED 2026-11-03 (New hire)
- Manager action: raise the IT equipment request at least 3 working days before start, i.e. by 2026-11-05 (Thursday)

### DEV-10
**Question:** When will I get my first salary?
**Answer:** Your first salary is currently **scheduled for Thursday, 26 November 2026** [R3]. This is because your recorded joining date is **25 October 2026**, which is **after** the joining-month cutoff of **15 October 2026**, so your first payment moves to the next month and covers your **joining part-month plus the next full month** [R1][R3].  

This is only a **scheduled estimate**, not confirmation of payment. Payroll requires a **verified IBAN** before salary can be paid, so please make sure any unresolved bank details are confirmed with Payroll [R3].
**Expected points:**
- Start date 2026-10-25 is after the 2026-10 cut-off 2026-10-15
- First salary is paid on the next month's pay date 2026-11-26 (Thursday)
- That payment includes the part-month of joining plus the full next month
- 28 November 2026 is a Saturday, so the pay date moves back to the Thursday

### DEV-11
**Question:** I started on 27 September. When does my first salary come?
**Answer:** Your first salary is scheduled for **Wednesday, 28 October 2026** [R3].  

Why: your recorded start date is **27 September 2026**, and the payroll rule says that if a start date is **after** the monthly payroll cut-off, the first salary moves to the **next month’s pay date**. The payroll procedure says the cut-off is the **15th of the month** and pay day is the **28th** [R1][S1]. Your start date is after the joining-month cut-off, so the scheduled first payment is the October pay run [R1]. The procedure also says this first payment covers your **part-month of joining plus the full next month** [S1][R3].  

Important: this is a **scheduled estimate, not a confirmation of payment**. Payment still requires a **verified IBAN**; please confirm any unresolved bank details with Payroll [R1][S1].
**Expected points:**
- Start date 2026-09-27 is after the 2026-09 cut-off 2026-09-15
- First salary is paid on the next month's pay date 2026-10-28 (Wednesday)
- That payment includes the part-month of joining plus the full next month

### DEV-12
**Question:** How long do I have to complete my HSE induction? I'll be working at Ras Laffan.
**Answer:** For Ras Laffan Site staff, the full HSE induction must be completed on your first working day. It starts at 07:00 after you report at 06:30, and you may not go beyond the site office until it is signed off. [S1][S2]

For you, the recorded HSE induction task is **not started** and is due on **2026-11-08**. [R2] Your start date is **2026-11-08**, which is a **Sunday**. [R1] [R3]

So, you do **not** have additional days after starting to finish it; it is required on day one at Ras Laffan. [S1][S2]

If you need the exact first-day reporting location again, HR/PRO should confirm it with you.
**Expected points:**
- Site-based: the full induction is on the first working day 2026-11-08 (Sunday), starting 07:00
- No access beyond the site office until it is signed off (ONB-06 v2.0, effective 2026-05-01)
- The FAQ answer (30 days) is outdated (FAQ last reviewed March 2025); the procedure wins over the FAQ

### DEV-13
**Question:** Can my wife and children join me in Qatar, and how long does the family residence permit take?
**Answer:** Yes — as an **overseas hire**, your family joining you in Qatar is possible in principle, but Al Dana’s FAQ says this depends on your **contract terms** and the **government’s rules at the time**, so HR and PRO need to confirm it for you rather than the FAQ giving a fixed yes/no answer [S1]. The handbook also shows that overseas hires have **pre-arrival visa paperwork handled by PRO** and then a **QID/residence permit application** after arrival, but it does **not** set a family-joining rule [S2][S3]. If you want the exact family sponsorship position, please ask **HR and PRO** [S1].

For the **family residence permit / QID timing**, there is **no guaranteed processing time** in the supplied controlling procedure. ONB-02 says Al Dana **aims to start** the employee’s QID/residence permit process within **ten working days of the employee’s start date**, but it also says **we do not quote processing times for government steps, because they are not ours to promise** [S3]. So I can’t give a confirmed timeframe for your wife and children’s residence permits from the available sources; HR/PRO must confirm the current official timeline [S3][S1].

For your own status, the employee record shows you are an **overseas hire** and the open QID/residence permit task is **in progress**, owned by **PRO**, due **2026-10-11**, and it is **overdue** [R1][R2].
**Expected points:**
- The onboarding documents do not cover family residence
- Refer to HR and the PRO desk
- Does not invent a process or a processing time

### DEV-14
**Question:** Can you tell me when NH-2610 starts and which of her tasks are still open? We'll be working together.
**Answer:** I cannot share that record. Please contact HR.
**Expected points:**
- Politely declines: an employee may only see their own record; managers see their direct reports
- Offers a safe alternative, e.g. ask HR or her manager

### DEV-15
**Question:** في أي ساعة وأين أحضر في أول يوم عمل لي؟ وماذا يجب أن أحضر معي؟
**Answer:** بحسب الإجراء المعتمد، يجب أن تحضر في **دوحة HQ الساعة 08:00** في اليوم الأول، وتراجع **الاستقبال في الطابق الأرضي، المقر الرئيسي في وست باي**، وتسأل عن **منسق HR للانضمام**. [S5]

وبخصوص ما يجب أن تحضره:
- **QID الأصلي** لأنك **مواطن قطري**، وليس جواز سفر. [S5]
- **بيانات IBAN** إذا لم تكن قد أرسلتها إلى Payroll بعد. [S5]
- كما يطلب إجراء ما قبل الوصول من **QID وصورة شخصية حديثة ونسخة من أعلى مؤهل علمي وبيانات جهة اتصال للطوارئ وتوقيع Personal Data Notice**. [S4]

مهم أيضًا: تظهر لك مهمة **توقيع عقد العمل** وما زالت **In progress**، ويشترط إنشاء حساب IT بعد **تأكيد HR أن العقد موقّع**. [R2][S2]

إذا أردت، أستطيع أيضًا أن ألخص لك **قائمة اليوم الأول كاملة** وماذا سيحدث بعد وصولك.
**Expected points:**
- الحضور إلى مكتب الاستقبال في المقر الرئيسي (غرب الخليج، الدوحة) الساعة 08:00 صباحًا
- أول يوم عمل: الأحد 1 نوفمبر 2026 (2026-11-01)
- إحضار بطاقة الهوية القطرية (QID) وبيانات الآيبان (IBAN) إن لم تُرسل إلى قسم الرواتب
